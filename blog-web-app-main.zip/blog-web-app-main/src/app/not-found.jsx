const NotFoundPage = () => {
  return <>404 oldsongui</>;
};

export default NotFoundPage;
