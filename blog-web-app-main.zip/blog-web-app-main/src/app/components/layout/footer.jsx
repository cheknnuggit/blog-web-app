export const Footer = () => {
  return <></>;
};
